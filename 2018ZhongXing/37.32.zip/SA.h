
#ifndef _SA_
#define _SA_

#include "util.h"

#define SEED_SA 2	
#define SPEED 0.999				// �����ٶ�
#define Temp_Init 1				// ��ʼ�¶�
#define TemP_End 0.00000001		// ��ֹ�¶�
#define LOOP 80					// ��ѭ������

struct Answer{ 
	int solution[Size_Business]; double fit;
	int from; int to;
};

void SA();
void initsa();
void getnext(Answer &, int);
bool getfit(Answer &, int, int, int);
void fitness(Answer &);
void printsa(int);
void getbestsa();

#endif