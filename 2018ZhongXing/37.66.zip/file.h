#ifndef _file_h_
#define _file_h_

int read_file(char*, char**);
void write_result(char*, const char*);
void release_buff(char**, int);

#endif