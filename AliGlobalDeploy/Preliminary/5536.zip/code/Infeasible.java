import java.util.ArrayList;

/**
 * @author Erland
 *              不合法的解
 */

public class Infeasible {

    private Info info;
    public ArrayList<InfeasibleMachine> infeasibleMachine;
    double fitness;

    Infeasible(Info info){
        this.info = info;

        infeasibleMachine = new ArrayList<>();
        for(int i = 3001; i <= 6000; i++) {
            infeasibleMachine.add(new InfeasibleMachine(info, i));
        }
        for(int i = 1; i <= 2506; i++){
            infeasibleMachine.add(new InfeasibleMachine(info, i));
        }

        int index = 0;
        for(Instance instance : info.instances){
            infeasibleMachine.get(index % 5506).addInstance(instance);
            index++;
        }
    }

    Infeasible(Infeasible infeasible){
        this.info = infeasible.info;
        this.fitness = infeasible.fitness;
        this.infeasibleMachine = new ArrayList<>();
        for(InfeasibleMachine im : infeasible.infeasibleMachine){
            this.infeasibleMachine.add(new InfeasibleMachine(im));
        }
    }

    void getFitness(){
        fitness = 0.0;
        for(InfeasibleMachine mi : infeasibleMachine){
            mi.getFitness();
            fitness += mi.fitness;
        }
    }

}
