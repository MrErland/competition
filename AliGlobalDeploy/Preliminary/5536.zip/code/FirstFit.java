import java.util.ArrayList;

/**
 * @author Erland
 *          首次适应法--初解
 */

public class FirstFit {

    private Info info;
    public Solution solution;

    FirstFit(Info info){
        this.info = info;
        solution = new Solution(info);
    }

    public void run(){
        // 先检查每个机器是否合法，如果不合法，通过迁移合法化
        // 其次把没有分配的实例，按照约束放入各个物理机中，则求得初解

        for(MachineInstance mi : solution.machineInstances){
            while (!mi.isAllow()){
                int inst = mi.instances.get(0);
                if(!mi.removeInstance(info.indexInst.get(inst)))
                    System.out.println("remove error");
                boolean b = false;
                for (MachineInstance nextmi : solution.machineInstances){
                    if(nextmi.addInstance(info.indexInst.get(inst))) {
                        b = true;
                        solution.submits.add(new Submit(inst, nextmi.machine.id));      // 迁移的过程记录
                        break;
                    }
                }
                if(!b){
                    System.out.println("init status move error");
                }
            }
        }

        ArrayList<Integer> tmp = new ArrayList<>();
        for(int i = solution.instanceNoInMachines.size() - 1; i >= 0; i--){
            int inst = solution.instanceNoInMachines.get(i);
            if(info.indexApp.get(info.indexInst.get(inst).appId).diskHold >= 300) {
                tmp.add(inst);
                solution.instanceNoInMachines.remove(i);
            }
        }

        for(int inst : tmp){
            boolean b = false;
            for(int i = solution.machineInstances.size() - 1; i >= 0; i--){
                MachineInstance mi = solution.machineInstances.get(i);
                if(mi.addInstance(info.indexInst.get(inst))){
                    solution.submits.add(new Submit(inst, mi.machine.id));
                    b = true;
                    break;
                }
            }
            if(!b){
                System.out.println("add new instance error");
            }
        }

        for(int inst : solution.instanceNoInMachines){     // 对于没有分配的实例进行分配
            boolean b = false;
            for(int i = solution.machineInstances.size() - 1; i >= 0; i--){
                MachineInstance mi = solution.machineInstances.get(i);
                if(mi.addInstance(info.indexInst.get(inst))){
                    solution.submits.add(new Submit(inst, mi.machine.id));
                    b = true;
                    break;
                }
            }
            if(!b){
                System.out.println("add new instance error" + inst);
            }
        }

        info.submits = solution.submits;   //
    }
}
