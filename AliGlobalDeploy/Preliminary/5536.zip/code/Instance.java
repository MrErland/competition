
/**
 * @author Erland
 *      实例
 */

public class Instance {

    public static int NoMachine = -1;

    public int id;
    public int appId;
    public int machineId;

    Instance(int id, int appId, int machineId){
        this.id = id;
        this.appId = appId;
        this.machineId = machineId;
    }

}
