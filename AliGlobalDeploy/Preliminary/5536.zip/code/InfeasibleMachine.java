import java.util.ArrayList;

/**
 * @author Erland
 *              不合法的机器
 */


public class InfeasibleMachine {

    public int nowP, nowM, nowPM;               // 当前的P, M, PM
    public ArrayList<Integer> instances;       // 内部所有的实例
    public ArrayList<Double> nowCpu;           // cpu占用
    public ArrayList<Double> nowMem;
    public int nowDisk;

    private final static double MAX = 10000.0;

    private Info info;
    public Machine machine;
    public double fitness;          // 评价值

    InfeasibleMachine(Info info, int machineid){
        this.info = info;
        machine = info.indexMach.get(machineid);
        instances = new ArrayList<>();
        nowCpu = new ArrayList<>();
        nowMem = new ArrayList<>();
        nowDisk = 0;
        nowP = nowM = nowPM = 0;
        fitness = 0.0;
    }

    InfeasibleMachine(InfeasibleMachine mi){
        this.info = mi.info;
        this.machine = mi.machine;

        this.fitness = mi.fitness;
        this.nowP = mi.nowP;
        this.nowM = mi.nowM;
        this.nowPM = mi.nowPM;
        this.nowDisk = mi.nowDisk;
        this.instances = new ArrayList<>();
        for(int i : mi.instances){
            this.instances.add(i);
        }
        this.nowCpu = new ArrayList<>();
        this.nowMem = new ArrayList<>();
        for(int i = 0; i < mi.nowCpu.size(); i++ ){
            this.nowCpu.add(mi.nowCpu.get(i));
            this.nowMem.add(mi.nowMem.get(i));
        }
    }

    public void addInstance(Instance instance){     // 直接插入，不考虑合法性
        App app = info.indexApp.get(instance.appId);
        nowP += app.P;
        nowM += app.M;
        nowPM += app.PM;
        nowDisk += app.diskHold;
        instances.add(instance.id);
        int n = app.cpuHold.size();
        if(nowCpu.isEmpty()){
            for(int i = 0; i < n; i++){
                nowCpu.add(app.cpuHold.get(i));
                nowMem.add(app.memHold.get(i));
            }
        }else{
            for (int i = 0; i < n; i++) {
                nowCpu.set(i, nowCpu.get(i) + app.cpuHold.get(i));
                nowMem.set(i, nowMem.get(i) + app.memHold.get(i));
            }
        }
    }

    public void removeInstance(Instance instance){
        if(instances.isEmpty()) return;
        int index = instances.indexOf(instance.id);
        if(index == -1) return;
        instances.remove(index);

        App app = info.indexApp.get(instance.appId);
        nowP -= app.P;
        nowM -= app.M;
        nowPM -= app.PM;
        nowDisk -= app.diskHold;

        int n = app.cpuHold.size();
        for(int i = 0; i < n; i++){
            nowCpu.set(i, nowCpu.get(i) - app.cpuHold.get(i));
            nowMem.set(i, nowMem.get(i) - app.memHold.get(i));
        }
    }

    public boolean isAllow(){
        if(instances.isEmpty()) return true;
        if(nowP > machine.PMax || nowM > machine.MMax || nowPM > machine.PMMax) return false;
        if(nowDisk > machine.disk) return false;
        for(int i = 0; i < nowCpu.size(); i++){
            if(nowCpu.get(i) > machine.cpu || nowMem.get(i) > machine.mem)
                return false;
        }

        int n = info.constraints.size();
        for (int i = 0; i < n; i++) {
            int app1 = info.constraints.get(i).appId1;
            int app2 = info.constraints.get(i).appId2;
            int count = info.constraints.get(i).count;
            int a = 0, b = 0;
            for (int inst : instances) {
                if (app1 == info.indexInst.get(inst).appId) a++;
                if (app2 == info.indexInst.get(inst).appId) b++;
            }
            if (app1 != app2) {
                if (a > 0 && b > count){
                    return false;
                }
            }else {
                if (a > count + 1) {
                    return false;
                }
            }
        }
        return true;
    }

    public void getFitness(){
        if(!isAllow()){
            fitness = MAX;
            return;
        }
        fitness = 0.0;
        if(instances.size() == 0) return;
        int n = info.apps.get(0).cpuHold.size();
        for(int i = 0; i < n; i++) {
            double c = nowCpu.get(i) / machine.cpu;
            fitness += (1.0 + 10.0 * (Math.exp(Math.max(0.0, c - 0.5)) - 1));
        }
        fitness /= n;
    }
}
