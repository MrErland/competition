import java.util.ArrayList;
import java.util.Random;

/**
 *@author Erland
 *              不合法解的优化过程，使之合法化
 */

public class SA_Infeasible {

    private Info info;
    private Infeasible infeasible;
    private Random random;
    private double tempInit;
    private double tempEnd;
    private double speed;
    private int loop;

    SA_Infeasible(Info info){
        this.info = info;
        infeasible = new Infeasible(info);
        random = new Random();
        random.setSeed(1);
        tempInit = 10000;
        tempEnd = 0.01;
        speed = 0.99;
        loop = 50;
    }

    public void run() {
        double T, de;
        infeasible.getFitness();
        Infeasible tmpInfeasible = new Infeasible(infeasible);
        T = tempInit;
        long cnt = 0;
        while (T > tempEnd){
            for(int i = 0; i < loop; i++){
                moveInstance(infeasible, 10);    // 迁移
                exchangeInstance(10);       // 交换

                de = infeasible.fitness - tmpInfeasible.fitness;
                if (de < 0) {         // 更优解
                    tmpInfeasible = new Infeasible(infeasible);
                } else {              // 差解
                    if (Math.random() < Math.exp(-de / T)) {
                        tmpInfeasible = new Infeasible(infeasible);   // 接受
                    } else {
                        infeasible = new Infeasible(tmpInfeasible);    // 放弃
                    }
                }
            }
            T *= speed;
            System.out.println("count:" + cnt++ + " nowScore:" + infeasible.fitness + " machine:" + getMachine(infeasible));
        }
    }

    private int getMachine(Infeasible infeasible){
        int cnt = 0;
        for(InfeasibleMachine im : infeasible.infeasibleMachine){
            if(!im.isAllow()) cnt++;
        }
        return cnt;
    }

    private void moveInstance(Infeasible infeasible, int times) {
        int randMachineA, randMachineB, instA;
        for(int i = 0; i < times; i++) {
            randMachineA = random.nextInt(5506);
            randMachineB = random.nextInt(5506);
            if(randMachineA == randMachineB) continue;
            InfeasibleMachine randA = infeasible.infeasibleMachine.get(randMachineA);
            InfeasibleMachine randB = infeasible.infeasibleMachine.get(randMachineB);
            instA = randA.instances.get(random.nextInt(randA.instances.size()));
            randA.removeInstance(info.indexInst.get(instA));   // 迁出
            randB.addInstance(info.indexInst.get(instA));
            double preA = randA.fitness;
            randA.getFitness();
            double nowA = randA.fitness;
            double preB = randB.fitness;
            randB.getFitness();
            double nowB = randB.fitness;
            infeasible.fitness = infeasible.fitness - preA - preB + nowA + nowB;
         }
    }

    private void exchangeInstance(int times) {
        int machineA, machineB, instA, instB;
        int n = infeasible.infeasibleMachine.size();
        for (int i = 0; i < times; i++) {
            machineA = random.nextInt(n);
            machineB = random.nextInt(n);
            if(machineA == machineB) continue;

            int na = infeasible.infeasibleMachine.get(machineA).instances.size();
            int nb = infeasible.infeasibleMachine.get(machineB).instances.size();
            instA = infeasible.infeasibleMachine.get(machineA).instances.get(random.nextInt(na));
            instB = infeasible.infeasibleMachine.get(machineB).instances.get(random.nextInt(nb));
            if(info.indexInst.get(instA).appId == info.indexInst.get(instB).appId) continue;
            infeasible.infeasibleMachine.get(machineA).removeInstance(info.indexInst.get(instA));
            infeasible.infeasibleMachine.get(machineA).addInstance(info.indexInst.get(instB));
            infeasible.infeasibleMachine.get(machineB).addInstance(info.indexInst.get(instA));
            infeasible.infeasibleMachine.get(machineB).removeInstance(info.indexInst.get(instB));

            double preA = infeasible.infeasibleMachine.get(machineA).fitness;
            double preB = infeasible.infeasibleMachine.get(machineB).fitness;
            infeasible.infeasibleMachine.get(machineA).getFitness();
            infeasible.infeasibleMachine.get(machineB).getFitness();
            double nowA = infeasible.infeasibleMachine.get(machineA).fitness;
            double nowB = infeasible.infeasibleMachine.get(machineB).fitness;
            infeasible.fitness = infeasible.fitness - preA - preB + nowA + nowB;
        }
    }

}
