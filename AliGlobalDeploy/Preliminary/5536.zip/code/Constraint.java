
/**
 * @author Erland
 *         干扰约束类
 */

public class Constraint {

    public int appId1;
    public int appId2;
    public int count;

    Constraint(int appId1, int appId2, int count){
        this.appId1 = appId1;
        this.appId2 = appId2;
        this.count = count;
    }
}
